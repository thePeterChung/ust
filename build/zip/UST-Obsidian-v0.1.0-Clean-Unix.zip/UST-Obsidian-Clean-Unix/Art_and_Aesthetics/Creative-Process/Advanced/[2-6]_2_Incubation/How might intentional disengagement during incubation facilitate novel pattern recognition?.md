**Question ID:** Creative-Process.A.2.3

**Concept:** [[Inversion]]

**Structure Part:** [[_Creative-Process-A-[2-6]_2_Incubation]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


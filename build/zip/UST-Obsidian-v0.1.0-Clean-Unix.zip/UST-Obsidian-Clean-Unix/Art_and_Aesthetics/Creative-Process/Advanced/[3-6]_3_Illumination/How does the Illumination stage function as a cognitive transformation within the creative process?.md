**Question ID:** Creative-Process.A.3.1

**Concept:** [[Transformation]]

**Structure Part:** [[_Creative-Process-A-[3-6]_3_Illumination]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


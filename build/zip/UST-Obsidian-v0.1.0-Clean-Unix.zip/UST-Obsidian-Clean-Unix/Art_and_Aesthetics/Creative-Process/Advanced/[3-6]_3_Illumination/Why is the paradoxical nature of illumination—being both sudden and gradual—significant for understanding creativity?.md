**Question ID:** Creative-Process.A.3.3

**Concept:** [[Paradox]]

**Structure Part:** [[_Creative-Process-A-[3-6]_3_Illumination]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


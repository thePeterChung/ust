**Question ID:** Creative-Process.A.5.12

**Concept:** [[Reflexivity]]

**Structure Part:** [[_Creative-Process-A-[5-6]_5_Elaboration]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


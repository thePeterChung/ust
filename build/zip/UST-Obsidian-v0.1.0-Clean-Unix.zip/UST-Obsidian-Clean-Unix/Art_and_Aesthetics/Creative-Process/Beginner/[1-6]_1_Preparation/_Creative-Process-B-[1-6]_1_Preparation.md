[[_Creative-Process]]

1. Preparation → Gathering information and materials, initial conscious work

Questions for **[1/6] 1. Preparation** at level **Beginner**:

- [[What activities typically happen during the Preparation stage?]] B.1.1
- [[How does gathering information influence creativity?]] B.1.2
- [[Why is conscious effort important in this early phase?]] B.1.3
- [[What materials or resources might an artist collect during Preparation?]] B.1.4
- [[How does Preparation set the foundation for later stages?]] B.1.5
- [[What emotions might an artist feel during Preparation?]] B.1.6
- [[What if the Preparation phase is rushed or incomplete?]] B.1.7
- [[How does the artist's focus shape this stage?]] B.1.8
- [[What kinds of problems can arise in Preparation?]] B.1.9
- [[How might an artist frame the problem they want to solve?]] B.1.10
- [[Why is this stage necessary for effective creative work?]] B.1.11
- [[What next steps follow logically from Preparation?]] B.1.12

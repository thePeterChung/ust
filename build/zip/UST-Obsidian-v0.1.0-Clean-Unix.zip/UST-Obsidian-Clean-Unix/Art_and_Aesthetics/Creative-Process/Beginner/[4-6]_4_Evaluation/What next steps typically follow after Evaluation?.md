**Question ID:** Creative-Process.B.4.9

**Concept:** [[Continuity]]

**Structure Part:** [[_Creative-Process-B-[4-6]_4_Evaluation]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


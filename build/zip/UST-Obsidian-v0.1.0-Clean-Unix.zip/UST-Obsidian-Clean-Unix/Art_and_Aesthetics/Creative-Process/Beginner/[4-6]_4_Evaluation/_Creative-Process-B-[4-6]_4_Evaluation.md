[[_Creative-Process]]

4. Evaluation → Critical assessment of the insight

Questions for **[4/6] 4. Evaluation** at level **Beginner**:

- [[What is the purpose of the Evaluation stage in the creative process?]] B.4.1
- [[How does an artist assess the quality of their insight or idea?]] B.4.2
- [[Why is critical thinking important during Evaluation?]] B.4.3
- [[What criteria might be used to judge an idea’s value?]] B.4.4
- [[How can feedback from others influence the Evaluation phase?]] B.4.5
- [[What emotions might an artist experience when evaluating their work?]] B.4.6
- [[What if the Evaluation reveals flaws or gaps in the idea?]] B.4.7
- [[How does Evaluation help decide whether to continue or revise?]] B.4.8
- [[What next steps typically follow after Evaluation?]] B.4.9
- [[How does this stage connect logically to Illumination and Elaboration?]] B.4.10
- [[Why might Evaluation be challenging for artists emotionally or cognitively?]] B.4.11
- [[How can framing influence the outcomes of Evaluation?]] B.4.12

**Question ID:** Creative-Process.B.5.5

**Concept:** [[Focus]]

**Structure Part:** [[_Creative-Process-B-[5-6]_5_Elaboration]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


**Question ID:** Creative-Process.I.1.8

**Concept:** [[Mood]]

**Structure Part:** [[_Creative-Process-I-[1-6]_1_Preparation]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


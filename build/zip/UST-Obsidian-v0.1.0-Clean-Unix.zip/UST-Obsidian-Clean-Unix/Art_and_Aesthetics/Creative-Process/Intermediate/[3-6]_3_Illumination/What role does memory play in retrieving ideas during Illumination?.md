**Question ID:** Creative-Process.I.3.5

**Concept:** [[Memory]]

**Structure Part:** [[_Creative-Process-I-[3-6]_3_Illumination]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


[[_Creative-Process]]

4. Evaluation → Critical assessment of the insight

Questions for **[4/6] 4. Evaluation** at level **Intermediate**:

- [[How does Evaluation help distinguish viable ideas from less effective ones?]] I.4.1
- [[What criteria can be applied to critically assess creative insights?]] I.4.2
- [[Why is reflexivity important during the Evaluation stage?]] I.4.3
- [[How can feedback from diverse perspectives improve the evaluation process?]] I.4.4
- [[What tensions arise when an artist evaluates their own work?]] I.4.5
- [[How might cognitive biases impact evaluation outcomes?]] I.4.6
- [[What strategies can mitigate emotional challenges during Evaluation?]] I.4.7
- [[How does framing influence the judgment made in this phase?]] I.4.8
- [[In what ways does Evaluation inform decisions to iterate or proceed?]] I.4.9
- [[What if Evaluation reveals fundamental flaws—how should the creative process adapt?]] I.4.10
- [[How does Evaluation connect logically with prior Illumination and subsequent Elaboration?]] I.4.11
- [[Why is Evaluation essential for sustaining creative integrity?]] I.4.12

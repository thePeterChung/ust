**Question ID:** Creative-Process.I.5.1

**Concept:** [[Transformation]]

**Structure Part:** [[_Creative-Process-I-[5-6]_5_Elaboration]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


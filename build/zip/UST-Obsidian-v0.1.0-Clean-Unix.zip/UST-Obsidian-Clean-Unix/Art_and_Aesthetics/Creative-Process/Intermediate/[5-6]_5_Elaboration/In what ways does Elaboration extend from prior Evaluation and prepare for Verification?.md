**Question ID:** Creative-Process.I.5.9

**Concept:** [[Continuity]]

**Structure Part:** [[_Creative-Process-I-[5-6]_5_Elaboration]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


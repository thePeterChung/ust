**Question ID:** Creative-Process.ME.3.8

**Concept:** [[Agency]]

**Structure Part:** [[_Creative-Process-ME-[3-6]_3_Illumination]]

**Level:** Meta/Expert

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


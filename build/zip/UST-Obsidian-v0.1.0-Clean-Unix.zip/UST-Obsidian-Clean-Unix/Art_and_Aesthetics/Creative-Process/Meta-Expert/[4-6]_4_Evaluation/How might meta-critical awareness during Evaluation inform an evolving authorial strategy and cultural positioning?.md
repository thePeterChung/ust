**Question ID:** Creative-Process.ME.4.11

**Concept:** [[Authorial_Strategy]]

**Structure Part:** [[_Creative-Process-ME-[4-6]_4_Evaluation]]

**Level:** Meta/Expert

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


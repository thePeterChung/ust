[[_Machine-Learning-Loop]]

2. Data Collection → Gathering raw data from various sources relevant to the defined problem

Questions for **[2/10] 2. Data Collection** at level **Advanced**:

- [[How can the epistemological foundations of data collection methods influence ML outcomes?]] A.2.1
- [[What strategies exist for identifying and mitigating systemic biases in large-scale data sets?]] A.2.2
- [[How does the interplay between data heterogeneity and representativeness affect model generalizability?]] A.2.3
- [[In what ways can ethical frameworks guide decisions about data privacy and consent?]] A.2.4
- [[How do power asymmetries manifest in data collection and influence ML applications?]] A.2.5
- [[What role does data provenance play in assessing reliability and reproducibility?]] A.2.6
- [[How can multi-modal data integration challenge traditional system boundaries?]] A.2.7
- [[What are the consequences of feedback loops embedded in data generation processes?]] A.2.8
- [[How can uncertainty in data sources be rigorously quantified and managed?]] A.2.9
- [[How might advances in sensor technology reshape paradigms of data collection?]] A.2.10
- [[How can interdisciplinary collaboration enhance data collection strategies for complex problems?]] A.2.11
- [[What tensions arise between data accessibility and security in contemporary ML ecosystems?]] A.2.12

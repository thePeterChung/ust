**Question ID:** Machine-Learning-Loop.A.3.6

**Concept:** [[Continuity]]

**Structure Part:** [[_Machine-Learning-Loop-A-[3-10]_3_Data_Preparation]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


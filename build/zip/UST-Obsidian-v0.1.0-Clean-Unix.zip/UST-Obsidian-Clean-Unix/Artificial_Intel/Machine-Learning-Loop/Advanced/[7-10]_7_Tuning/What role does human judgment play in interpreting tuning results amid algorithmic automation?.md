**Question ID:** Machine-Learning-Loop.A.7.9

**Concept:** [[Agency]]

**Structure Part:** [[_Machine-Learning-Loop-A-[7-10]_7_Tuning]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


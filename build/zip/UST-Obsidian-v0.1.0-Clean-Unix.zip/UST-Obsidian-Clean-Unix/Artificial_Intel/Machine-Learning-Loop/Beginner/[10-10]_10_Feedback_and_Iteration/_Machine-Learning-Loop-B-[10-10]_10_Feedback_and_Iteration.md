[[_Machine-Learning-Loop]]



Questions for **[10/10] 10. Feedback and Iteration** at level **Beginner**:

- [[What is the role of feedback in improving machine learning systems?]] B.10.1
- [[How does iteration help address errors or shortcomings found during monitoring?]] B.10.2
- [[Why is it important to revisit earlier stages based on new insights?]] B.10.3
- [[What challenges can arise when implementing iterative changes in deployed systems?]] B.10.4
- [[How can feedback loops enhance the accuracy and fairness of models over time?]] B.10.5
- [[What are the risks of repeating the same mistakes during iteration?]] B.10.6
- [[How do teams prioritize which feedback to act on in the iteration process?]] B.10.7
- [[What emotions or motivations drive teams to continuously improve ML systems?]] B.10.8
- [[What if iteration leads to unexpected new problems or trade-offs?]] B.10.9
- [[How does iterative improvement reflect broader cycles in technological development?]] B.10.10
- [[What tone is effective when communicating iterative changes to users or stakeholders?]] B.10.11
- [[How does iteration encourage reflexivity and learning within machine learning teams?]] B.10.12

**Question ID:** Creative-Process.A.1.5

**Concept:** [[Pattern]]

**Structure Part:** [[_Creative-Process-A-[1-6]_1_Preparation]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


[[_Creative-Process]]

1. Preparation → Gathering information and materials, initial conscious work

Questions for **[1/6] 1. Preparation** at level **Advanced**:

- [[How can the framing of initial research during Preparation influence the conceptual boundaries of creative work|How can the framing of initial research during Preparation influence the conceptual boundaries of creative work?]] A.1.1
- [[In what ways does the artist’s intention mediate the selection and interpretation of preparatory materials|In what ways does the artist’s intention mediate the selection and interpretation of preparatory materials?]] A.1.2
- [[How might hierarchical structuring of information affect the efficiency and depth of the Preparation phase|How might hierarchical structuring of information affect the efficiency and depth of the Preparation phase?]] A.1.3
- [[Why is the balance between breadth and depth crucial in gathering preparatory knowledge|Why is the balance between breadth and depth crucial in gathering preparatory knowledge?]] A.1.4
- [[How can preparation practices be optimized to account for cognitive biases in problem framing|How can preparation practices be optimized to account for cognitive biases in problem framing?]] A.1.5
- [[What role does boundary setting play in limiting scope to enhance creative focus during Preparation|What role does boundary setting play in limiting scope to enhance creative focus during Preparation?]] A.1.6
- [[How might the iterative revisiting of preparatory materials foster emergent insights|How might the iterative revisiting of preparatory materials foster emergent insights?]] A.1.7
- [[In what ways can affective states during Preparation influence subsequent creative stages|In what ways can affective states during Preparation influence subsequent creative stages?]] A.1.8
- [[How does Preparation serve as a form of cognitive scaffolding for creative problem solving|How does Preparation serve as a form of cognitive scaffolding for creative problem solving?]] A.1.9
- [[What are the implications of inadequate Preparation on the emergence and development of ideas|What are the implications of inadequate Preparation on the emergence and development of ideas?]] A.1.10
- [[How can artists integrate interdisciplinary perspectives effectively during Preparation|How can artists integrate interdisciplinary perspectives effectively during Preparation?]] A.1.11
- [[What logical continuities link Preparation to the Incubation stage in the creative cycle|What logical continuities link Preparation to the Incubation stage in the creative cycle?]] A.1.12

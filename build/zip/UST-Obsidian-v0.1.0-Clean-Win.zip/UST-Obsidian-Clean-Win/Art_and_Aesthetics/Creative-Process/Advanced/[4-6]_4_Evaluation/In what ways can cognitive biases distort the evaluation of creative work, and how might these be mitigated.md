**Question ID:** Creative-Process.A.4.2

**Concept:** [[Pattern]]

**Structure Part:** [[_Creative-Process-A-[4-6]_4_Evaluation]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


**Question ID:** Creative-Process.A.6.10

**Concept:** [[Perspective]]

**Structure Part:** [[_Creative-Process-A-[6-6]_6_Verification]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


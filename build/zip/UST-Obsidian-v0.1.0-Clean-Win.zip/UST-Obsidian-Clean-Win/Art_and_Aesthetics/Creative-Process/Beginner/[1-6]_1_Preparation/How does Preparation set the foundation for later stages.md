**Question ID:** Creative-Process.B.1.5

**Concept:** [[Hierarchy]]

**Structure Part:** [[_Creative-Process-B-[1-6]_1_Preparation]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


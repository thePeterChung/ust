**Question ID:** Creative-Process.B.1.3

**Concept:** [[Agency]]

**Structure Part:** [[_Creative-Process-B-[1-6]_1_Preparation]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


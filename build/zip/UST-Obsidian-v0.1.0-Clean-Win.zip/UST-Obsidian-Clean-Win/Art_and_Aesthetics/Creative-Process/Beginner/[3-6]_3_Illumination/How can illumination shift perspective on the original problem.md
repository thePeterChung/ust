**Question ID:** Creative-Process.B.3.7

**Concept:** [[Perspective]]

**Structure Part:** [[_Creative-Process-B-[3-6]_3_Illumination]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


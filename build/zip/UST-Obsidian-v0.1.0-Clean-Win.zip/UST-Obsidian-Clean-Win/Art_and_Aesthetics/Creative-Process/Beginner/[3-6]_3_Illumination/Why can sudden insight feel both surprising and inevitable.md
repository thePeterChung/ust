**Question ID:** Creative-Process.B.3.3

**Concept:** [[Paradox]]

**Structure Part:** [[_Creative-Process-B-[3-6]_3_Illumination]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


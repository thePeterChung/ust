[[_Creative-Process]]

3. Illumination → Sudden insight or 'Aha' moment

Questions for **[3/6] 3. Illumination** at level **Beginner**:

- [[What characterizes the Illumination stage|What characterizes the Illumination stage?]] B.3.1
- [[How does the 'Aha' moment impact the creative process|How does the 'Aha' moment impact the creative process?]] B.3.2
- [[Why can sudden insight feel both surprising and inevitable|Why can sudden insight feel both surprising and inevitable?]] B.3.3
- [[What if Illumination does not occur—how might the process change|What if Illumination does not occur—how might the process change?]] B.3.4
- [[How does illumination affect the artist's sense of agency|How does illumination affect the artist's sense of agency?]] B.3.5
- [[What emotions accompany the moment of insight|What emotions accompany the moment of insight?]] B.3.6
- [[How can illumination shift perspective on the original problem|How can illumination shift perspective on the original problem?]] B.3.7
- [[What next steps logically follow Illumination|What next steps logically follow Illumination?]] B.3.8
- [[How does this stage connect to previous Incubation|How does this stage connect to previous Incubation?]] B.3.9
- [[Why might illumination be difficult to communicate to others|Why might illumination be difficult to communicate to others?]] B.3.10
- [[What role does memory play in illumination|What role does memory play in illumination?]] B.3.11
- [[How can the artist frame this moment to maximize creative potential|How can the artist frame this moment to maximize creative potential?]] B.3.12

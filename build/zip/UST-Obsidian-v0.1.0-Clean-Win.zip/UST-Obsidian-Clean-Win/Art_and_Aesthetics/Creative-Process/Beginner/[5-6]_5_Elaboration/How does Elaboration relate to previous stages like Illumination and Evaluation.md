**Question ID:** Creative-Process.B.5.8

**Concept:** [[Cause_and_Effect]]

**Structure Part:** [[_Creative-Process-B-[5-6]_5_Elaboration]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


**Question ID:** Creative-Process.B.6.1

**Concept:** [[Closure]]

**Structure Part:** [[_Creative-Process-B-[6-6]_6_Verification]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


**Question ID:** Creative-Process.B.6.4

**Concept:** [[Inference]]

**Structure Part:** [[_Creative-Process-B-[6-6]_6_Verification]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


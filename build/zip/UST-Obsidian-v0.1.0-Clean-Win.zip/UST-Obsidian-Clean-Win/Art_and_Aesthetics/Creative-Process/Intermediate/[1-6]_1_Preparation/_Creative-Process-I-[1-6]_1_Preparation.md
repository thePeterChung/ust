[[_Creative-Process]]

1. Preparation → Gathering information and materials, initial conscious work

Questions for **[1/6] 1. Preparation** at level **Intermediate**:

- [[How does the Preparation stage influence the scope of a creative project|How does the Preparation stage influence the scope of a creative project?]] I.1.1
- [[In what ways can initial research shape the trajectory of creative work|In what ways can initial research shape the trajectory of creative work?]] I.1.2
- [[Why might an artist’s intention evolve during Preparation|Why might an artist’s intention evolve during Preparation?]] I.1.3
- [[How can one balance gathering information with starting to create|How can one balance gathering information with starting to create?]] I.1.4
- [[What are potential risks of insufficient preparation|What are potential risks of insufficient preparation?]] I.1.5
- [[How does hierarchy of information affect the artist’s choices in this phase|How does hierarchy of information affect the artist’s choices in this phase?]] I.1.6
- [[What if new perspectives challenge the initial framing during Preparation|What if new perspectives challenge the initial framing during Preparation?]] I.1.7
- [[How might an artist’s mood influence the quality of Preparation|How might an artist’s mood influence the quality of Preparation?]] I.1.8
- [[How can iterative cycles of Preparation improve creative outcomes|How can iterative cycles of Preparation improve creative outcomes?]] I.1.9
- [[Why is boundary-setting important during Preparation|Why is boundary-setting important during Preparation?]] I.1.10
- [[How does this stage interact with previous experiences or memory|How does this stage interact with previous experiences or memory?]] I.1.11
- [[What next steps should an artist anticipate after Preparation|What next steps should an artist anticipate after Preparation?]] I.1.12

**Question ID:** Creative-Process.I.2.12

**Concept:** [[Uncertainty]]

**Structure Part:** [[_Creative-Process-I-[2-6]_2_Incubation]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


[[_Creative-Process]]

3. Illumination → Sudden insight or 'Aha' moment

Questions for **[3/6] 3. Illumination** at level **Intermediate**:

- [[How does the Illumination stage transform latent ideas into explicit insight|How does the Illumination stage transform latent ideas into explicit insight?]] I.3.1
- [[What cognitive processes underlie the 'Aha!' moment during Illumination|What cognitive processes underlie the 'Aha!' moment during Illumination?]] I.3.2
- [[Why can illumination feel paradoxical, blending surprise with recognition|Why can illumination feel paradoxical, blending surprise with recognition?]] I.3.3
- [[How might an artist frame the insight to facilitate further development|How might an artist frame the insight to facilitate further development?]] I.3.4
- [[What role does memory play in retrieving ideas during Illumination|What role does memory play in retrieving ideas during Illumination?]] I.3.5
- [[How do shifts in perspective contribute to the breakthrough experienced|How do shifts in perspective contribute to the breakthrough experienced?]] I.3.6
- [[What emotional effects can accompany the Illumination stage|What emotional effects can accompany the Illumination stage?]] I.3.7
- [[How does Illumination set up the Evaluation phase that follows|How does Illumination set up the Evaluation phase that follows?]] I.3.8
- [[What if the Illumination is incomplete or ambiguous—how should an artist proceed|What if the Illumination is incomplete or ambiguous—how should an artist proceed?]] I.3.9
- [[How does agency manifest during the moment of Illumination|How does agency manifest during the moment of Illumination?]] I.3.10
- [[What implications does Illumination have for the overall creative cycle|What implications does Illumination have for the overall creative cycle?]] I.3.11
- [[Why is it important to capture insights immediately after Illumination|Why is it important to capture insights immediately after Illumination?]] I.3.12

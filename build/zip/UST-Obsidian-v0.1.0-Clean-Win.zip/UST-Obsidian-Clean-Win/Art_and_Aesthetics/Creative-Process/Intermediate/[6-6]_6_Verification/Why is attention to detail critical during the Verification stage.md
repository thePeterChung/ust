**Question ID:** Creative-Process.I.6.3

**Concept:** [[Focus]]

**Structure Part:** [[_Creative-Process-I-[6-6]_6_Verification]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


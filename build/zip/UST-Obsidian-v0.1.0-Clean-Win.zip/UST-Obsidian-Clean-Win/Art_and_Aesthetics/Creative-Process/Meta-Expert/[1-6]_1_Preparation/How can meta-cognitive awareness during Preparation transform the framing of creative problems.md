**Question ID:** Creative-Process.ME.1.1

**Concept:** [[Reflexivity]]

**Structure Part:** [[_Creative-Process-ME-[1-6]_1_Preparation]]

**Level:** Meta/Expert

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


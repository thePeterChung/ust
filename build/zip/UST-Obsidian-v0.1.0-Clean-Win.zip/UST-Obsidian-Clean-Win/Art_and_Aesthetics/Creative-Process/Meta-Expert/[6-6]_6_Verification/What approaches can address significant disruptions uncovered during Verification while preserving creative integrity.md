**Question ID:** Creative-Process.ME.6.6

**Concept:** [[Disruption]]

**Structure Part:** [[_Creative-Process-ME-[6-6]_6_Verification]]

**Level:** Meta/Expert

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


**Question ID:** Machine-Learning-Loop.A.2.9

**Concept:** [[Uncertainty]]

**Structure Part:** [[_Machine-Learning-Loop-A-[2-10]_2_Data_Collection]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


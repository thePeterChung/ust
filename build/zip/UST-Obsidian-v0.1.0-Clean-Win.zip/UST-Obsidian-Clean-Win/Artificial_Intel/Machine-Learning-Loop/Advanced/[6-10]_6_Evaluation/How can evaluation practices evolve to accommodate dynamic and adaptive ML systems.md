**Question ID:** Machine-Learning-Loop.A.6.9

**Concept:** [[Transformation]]

**Structure Part:** [[_Machine-Learning-Loop-A-[6-10]_6_Evaluation]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


**Question ID:** Machine-Learning-Loop.A.7.6

**Concept:** [[Intention]]

**Structure Part:** [[_Machine-Learning-Loop-A-[7-10]_7_Tuning]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


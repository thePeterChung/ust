**Question ID:** Machine-Learning-Loop.A.8.1

**Concept:** [[System]]

**Structure Part:** [[_Machine-Learning-Loop-A-[8-10]_8_Deployment]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


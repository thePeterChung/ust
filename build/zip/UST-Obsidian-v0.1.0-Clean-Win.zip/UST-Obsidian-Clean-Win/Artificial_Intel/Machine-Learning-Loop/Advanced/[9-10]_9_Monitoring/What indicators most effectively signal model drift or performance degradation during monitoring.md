**Question ID:** Machine-Learning-Loop.A.9.2

**Concept:** [[Cause_and_Effect]]

**Structure Part:** [[_Machine-Learning-Loop-A-[9-10]_9_Monitoring]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


**Question ID:** Creative-Process.A.1.2

**Concept:** [[Intention]]

**Structure Part:** [[_Creative-Process-A-[1-6]_1_Preparation]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


**Question ID:** Creative-Process.A.2.12

**Concept:** [[Agency]]

**Structure Part:** [[_Creative-Process-A-[2-6]_2_Incubation]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


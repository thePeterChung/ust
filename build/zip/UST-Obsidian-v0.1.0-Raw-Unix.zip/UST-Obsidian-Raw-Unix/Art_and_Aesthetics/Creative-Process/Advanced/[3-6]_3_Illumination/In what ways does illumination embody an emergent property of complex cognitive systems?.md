**Question ID:** Creative-Process.A.3.11

**Concept:** [[Emergence]]

**Structure Part:** [[_Creative-Process-A-[3-6]_3_Illumination]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


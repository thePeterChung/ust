**Question ID:** Creative-Process.A.5.8

**Concept:** [[Scale]]

**Structure Part:** [[_Creative-Process-A-[5-6]_5_Elaboration]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


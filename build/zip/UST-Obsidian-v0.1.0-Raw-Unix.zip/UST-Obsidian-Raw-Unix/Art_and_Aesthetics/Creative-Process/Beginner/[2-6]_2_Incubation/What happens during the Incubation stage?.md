**Question ID:** Creative-Process.B.2.1

**Concept:** [[Core_Structure]]

**Structure Part:** [[_Creative-Process-B-[2-6]_2_Incubation]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


**Question ID:** Creative-Process.B.2.10

**Concept:** [[Continuity]]

**Structure Part:** [[_Creative-Process-B-[2-6]_2_Incubation]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


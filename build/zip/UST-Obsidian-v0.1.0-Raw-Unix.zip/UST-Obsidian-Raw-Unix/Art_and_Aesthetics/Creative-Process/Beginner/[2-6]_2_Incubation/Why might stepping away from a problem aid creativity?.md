**Question ID:** Creative-Process.B.2.3

**Concept:** [[Inversion]]

**Structure Part:** [[_Creative-Process-B-[2-6]_2_Incubation]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


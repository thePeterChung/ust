[[_Creative-Process]]

2. Incubation → Subconscious processing and idea formation

Questions for **[2/6] 2. Incubation** at level **Beginner**:

- [[What happens during the Incubation stage?]] B.2.1
- [[How does subconscious processing differ from conscious effort?]] B.2.2
- [[Why might stepping away from a problem aid creativity?]] B.2.3
- [[What if no incubation occurs—how might that affect the outcome?]] B.2.4
- [[How can feedback loops occur in this stage?]] B.2.5
- [[What feelings or moods are commonly associated with Incubation?]] B.2.6
- [[How might incubation involve ambiguity or uncertainty?]] B.2.7
- [[What role does memory play in incubation?]] B.2.8
- [[How might an artist deliberately foster incubation?]] B.2.9
- [[What next might happen after incubation completes?]] B.2.10
- [[How can incubation be seen as a cycle or iterative process?]] B.2.11
- [[Why is Incubation critical despite seeming passive?]] B.2.12

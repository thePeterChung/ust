**Question ID:** Creative-Process.B.3.1

**Concept:** [[Core_Structure]]

**Structure Part:** [[_Creative-Process-B-[3-6]_3_Illumination]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


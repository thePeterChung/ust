**Question ID:** Creative-Process.B.4.8

**Concept:** [[Choice]]

**Structure Part:** [[_Creative-Process-B-[4-6]_4_Evaluation]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


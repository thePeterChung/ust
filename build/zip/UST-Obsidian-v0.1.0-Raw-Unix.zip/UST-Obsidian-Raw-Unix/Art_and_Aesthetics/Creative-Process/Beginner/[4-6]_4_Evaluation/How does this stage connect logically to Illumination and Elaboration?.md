**Question ID:** Creative-Process.B.4.10

**Concept:** [[Cause_and_Effect]]

**Structure Part:** [[_Creative-Process-B-[4-6]_4_Evaluation]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


**Question ID:** Creative-Process.I.1.1

**Concept:** [[Framing]]

**Structure Part:** [[_Creative-Process-I-[1-6]_1_Preparation]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


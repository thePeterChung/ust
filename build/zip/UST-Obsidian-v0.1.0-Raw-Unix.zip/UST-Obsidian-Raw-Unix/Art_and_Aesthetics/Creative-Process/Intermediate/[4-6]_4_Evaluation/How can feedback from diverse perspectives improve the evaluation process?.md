**Question ID:** Creative-Process.I.4.4

**Concept:** [[Feedback]]

**Structure Part:** [[_Creative-Process-I-[4-6]_4_Evaluation]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


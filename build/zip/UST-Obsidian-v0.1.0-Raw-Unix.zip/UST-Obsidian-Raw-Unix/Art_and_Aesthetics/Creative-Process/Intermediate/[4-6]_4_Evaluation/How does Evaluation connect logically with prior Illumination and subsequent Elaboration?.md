**Question ID:** Creative-Process.I.4.11

**Concept:** [[Cause_and_Effect]]

**Structure Part:** [[_Creative-Process-I-[4-6]_4_Evaluation]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


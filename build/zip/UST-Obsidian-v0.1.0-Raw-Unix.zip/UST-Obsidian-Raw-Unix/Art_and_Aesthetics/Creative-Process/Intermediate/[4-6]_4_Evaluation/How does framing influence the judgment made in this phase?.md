**Question ID:** Creative-Process.I.4.8

**Concept:** [[Framing]]

**Structure Part:** [[_Creative-Process-I-[4-6]_4_Evaluation]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


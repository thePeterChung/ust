**Question ID:** Creative-Process.I.4.2

**Concept:** [[Inference]]

**Structure Part:** [[_Creative-Process-I-[4-6]_4_Evaluation]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


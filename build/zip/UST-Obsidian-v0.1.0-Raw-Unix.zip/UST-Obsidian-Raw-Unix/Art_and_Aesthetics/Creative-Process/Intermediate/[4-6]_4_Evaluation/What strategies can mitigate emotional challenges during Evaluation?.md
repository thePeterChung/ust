**Question ID:** Creative-Process.I.4.7

**Concept:** [[Mood]]

**Structure Part:** [[_Creative-Process-I-[4-6]_4_Evaluation]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


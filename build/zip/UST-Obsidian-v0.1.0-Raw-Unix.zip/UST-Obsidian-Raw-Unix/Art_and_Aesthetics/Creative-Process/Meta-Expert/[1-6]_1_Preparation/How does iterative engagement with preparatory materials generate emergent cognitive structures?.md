**Question ID:** Creative-Process.ME.1.5

**Concept:** [[Emergence]]

**Structure Part:** [[_Creative-Process-ME-[1-6]_1_Preparation]]

**Level:** Meta/Expert

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


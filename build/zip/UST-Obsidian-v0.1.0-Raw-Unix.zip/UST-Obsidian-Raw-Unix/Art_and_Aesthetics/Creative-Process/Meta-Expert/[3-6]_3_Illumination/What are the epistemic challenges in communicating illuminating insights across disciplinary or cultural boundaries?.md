**Question ID:** Creative-Process.ME.3.10

**Concept:** [[Transformation_(Cultural)]]

**Structure Part:** [[_Creative-Process-ME-[3-6]_3_Illumination]]

**Level:** Meta/Expert

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


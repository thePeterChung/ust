**Question ID:** Creative-Process.ME.5.7

**Concept:** [[Reflexivity]]

**Structure Part:** [[_Creative-Process-ME-[5-6]_5_Elaboration]]

**Level:** Meta/Expert

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


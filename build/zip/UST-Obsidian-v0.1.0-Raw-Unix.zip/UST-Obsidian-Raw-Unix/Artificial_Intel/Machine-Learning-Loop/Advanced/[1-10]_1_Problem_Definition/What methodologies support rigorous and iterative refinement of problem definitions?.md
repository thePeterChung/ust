**Question ID:** Machine-Learning-Loop.A.1.11

**Concept:** [[Iteration]]

**Structure Part:** [[_Machine-Learning-Loop-A-[1-10]_1_Problem_Definition]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


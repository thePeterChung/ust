**Question ID:** Machine-Learning-Loop.A.6.2

**Concept:** [[Philosophy]]

**Structure Part:** [[_Machine-Learning-Loop-A-[6-10]_6_Evaluation]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


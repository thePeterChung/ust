**Question ID:** Machine-Learning-Loop.A.9.8

**Concept:** [[Tension]]

**Structure Part:** [[_Machine-Learning-Loop-A-[9-10]_9_Monitoring]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


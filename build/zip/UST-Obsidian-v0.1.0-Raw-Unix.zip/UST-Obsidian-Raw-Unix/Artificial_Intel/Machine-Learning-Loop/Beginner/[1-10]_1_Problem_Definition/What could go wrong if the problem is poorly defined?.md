**Question ID:** Machine-Learning-Loop.B.1.6

**Concept:** [[Uncertainty]]

**Structure Part:** [[_Machine-Learning-Loop-B-[1-10]_1_Problem_Definition]]

**Level:** Beginner

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


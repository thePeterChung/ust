**Question ID:** Machine-Learning-Loop.B.1.3

**Concept:** [[Framing]]

**Structure Part:** [[_Machine-Learning-Loop-B-[1-10]_1_Problem_Definition]]

**Level:** Beginner

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


[[_Machine-Learning-Loop]]

1. Problem Definition → Identify the task to be solved, often framed as a predictive or classification problem

Questions for **[1/10] 1. Problem Definition** at level **Beginner**:

- [[What is the specific task or question the system is trying to answer?]] B.1.1
- [[How does defining the problem shape the rest of the machine learning process?]] B.1.2
- [[Why is it important to frame the problem before collecting data?]] B.1.3
- [[What assumptions are being made about the nature of the problem?]] B.1.4
- [[How does the problem type (e.g., classification, regression) affect design choices?]] B.1.5
- [[What could go wrong if the problem is poorly defined?]] B.1.6
- [[What real-world constraints might influence how the problem is framed?]] B.1.7
- [[What if two teams define the same problem differently—how might their solutions diverge?]] B.1.8
- [[How might the problem definition affect the user’s experience or trust in the system?]] B.1.9
- [[What emotions or ethical concerns might arise when framing machine learning problems involving humans?]] B.1.10
- [[How does the choice of performance metric reflect assumptions about what matters?]] B.1.11
- [[What makes a machine learning problem definition clear and actionable?]] B.1.12

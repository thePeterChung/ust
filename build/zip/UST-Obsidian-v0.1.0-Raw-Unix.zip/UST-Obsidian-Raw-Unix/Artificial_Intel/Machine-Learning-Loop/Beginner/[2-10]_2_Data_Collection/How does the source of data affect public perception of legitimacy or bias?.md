**Question ID:** Machine-Learning-Loop.B.2.9

**Concept:** [[Power]]

**Structure Part:** [[_Machine-Learning-Loop-B-[2-10]_2_Data_Collection]]

**Level:** Beginner

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


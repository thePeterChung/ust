**Question ID:** Machine-Learning-Loop.B.3.7

**Concept:** [[Evaluation]]

**Structure Part:** [[_Machine-Learning-Loop-B-[3-10]_3_Data_Preparation]]

**Level:** Beginner

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


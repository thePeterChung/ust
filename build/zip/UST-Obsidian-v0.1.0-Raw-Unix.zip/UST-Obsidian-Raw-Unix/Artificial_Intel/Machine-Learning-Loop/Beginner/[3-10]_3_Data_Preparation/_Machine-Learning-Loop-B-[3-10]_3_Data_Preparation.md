[[_Machine-Learning-Loop]]

3. Data Preparation → Cleaning, formatting, and structuring data for modeling

Questions for **[3/10] 3. Data Preparation** at level **Beginner**:

- [[What steps are needed to clean and format data for modeling?]] B.3.1
- [[How do missing values or inconsistencies affect model performance?]] B.3.2
- [[Why is normalization or scaling necessary in many ML problems?]] B.3.3
- [[What are some strategies for dealing with outliers or noise in the data?]] B.3.4
- [[How does feature engineering enhance the signal in raw data?]] B.3.5
- [[What risks arise from over-preprocessing or manipulating data?]] B.3.6
- [[How can we test whether data preparation improved the dataset?]] B.3.7
- [[What if we prepared the data using different tools or rules—how might the model change?]] B.3.8
- [[How does data preparation reflect the values or goals of the team preparing it?]] B.3.9
- [[What feelings of confidence or uncertainty might data preparation elicit in human reviewers?]] B.3.10
- [[What kinds of preparation make data more reusable for future projects?]] B.3.11
- [[What counts as ‘clean’ data, and who decides?]] B.3.12

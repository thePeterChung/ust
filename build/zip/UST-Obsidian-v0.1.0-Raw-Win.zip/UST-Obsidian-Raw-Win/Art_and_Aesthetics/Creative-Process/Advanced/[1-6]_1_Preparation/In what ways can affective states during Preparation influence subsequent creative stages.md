**Question ID:** Creative-Process.A.1.8

**Concept:** [[Mood]]

**Structure Part:** [[_Creative-Process-A-[1-6]_1_Preparation]]

**Level:** Advanced

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


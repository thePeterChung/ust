**Question ID:** Creative-Process.B.2.4

**Concept:** [[Cause_and_Effect]]

**Structure Part:** [[_Creative-Process-B-[2-6]_2_Incubation]]

**Level:** Beginner

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


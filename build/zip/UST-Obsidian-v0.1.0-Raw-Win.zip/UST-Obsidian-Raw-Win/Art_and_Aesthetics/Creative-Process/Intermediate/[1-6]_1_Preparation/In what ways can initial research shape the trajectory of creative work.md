**Question ID:** Creative-Process.I.1.2

**Concept:** [[Cause_and_Effect]]

**Structure Part:** [[_Creative-Process-I-[1-6]_1_Preparation]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


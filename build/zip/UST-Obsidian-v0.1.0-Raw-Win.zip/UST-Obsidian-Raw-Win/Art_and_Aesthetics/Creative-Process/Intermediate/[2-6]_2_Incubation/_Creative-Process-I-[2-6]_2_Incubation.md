[[_Creative-Process]]

2. Incubation → Subconscious processing and idea formation

Questions for **[2/6] 2. Incubation** at level **Intermediate**:

- [[How does Incubation facilitate the emergence of novel ideas subconsciously|How does Incubation facilitate the emergence of novel ideas subconsciously?]] I.2.1
- [[In what ways does incubation integrate prior knowledge with new input|In what ways does incubation integrate prior knowledge with new input?]] I.2.2
- [[Why is allowing mental rest important for incubation to succeed|Why is allowing mental rest important for incubation to succeed?]] I.2.3
- [[How can an artist intentionally cultivate an environment conducive to incubation|How can an artist intentionally cultivate an environment conducive to incubation?]] I.2.4
- [[What role does feedback play indirectly during Incubation|What role does feedback play indirectly during Incubation?]] I.2.5
- [[How does ambiguity contribute to creative breakthroughs in incubation|How does ambiguity contribute to creative breakthroughs in incubation?]] I.2.6
- [[What if an artist’s subconscious biases limit the incubation process|What if an artist’s subconscious biases limit the incubation process?]] I.2.7
- [[How can cycles of incubation and conscious thought interact dynamically|How can cycles of incubation and conscious thought interact dynamically?]] I.2.8
- [[What moods or emotions are most supportive of incubation|What moods or emotions are most supportive of incubation?]] I.2.9
- [[Why might incubation be misunderstood as inactivity rather than active processing|Why might incubation be misunderstood as inactivity rather than active processing?]] I.2.10
- [[How can understanding system boundaries enhance incubation outcomes|How can understanding system boundaries enhance incubation outcomes?]] I.2.11
- [[What are the implications of incubation for managing creative uncertainty|What are the implications of incubation for managing creative uncertainty?]] I.2.12

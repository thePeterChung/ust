**Question ID:** Creative-Process.I.4.12

**Concept:** [[Core_Structure]]

**Structure Part:** [[_Creative-Process-I-[4-6]_4_Evaluation]]

**Level:** Intermediate

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


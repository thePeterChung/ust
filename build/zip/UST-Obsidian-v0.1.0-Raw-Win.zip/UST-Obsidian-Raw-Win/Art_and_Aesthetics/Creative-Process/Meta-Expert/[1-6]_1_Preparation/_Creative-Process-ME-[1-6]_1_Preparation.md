[[_Creative-Process]]

1. Preparation → Gathering information and materials, initial conscious work

Questions for **[1/6] 1. Preparation** at level **Meta/Expert**:

- [[How can meta-cognitive awareness during Preparation transform the framing of creative problems|How can meta-cognitive awareness during Preparation transform the framing of creative problems?]] ME.1.1
- [[In what ways does cultural context mediate the boundary-setting and information hierarchy in Preparation|In what ways does cultural context mediate the boundary-setting and information hierarchy in Preparation?]] ME.1.2
- [[How might an artist’s epistemological assumptions influence the scope and depth of their preparatory research|How might an artist’s epistemological assumptions influence the scope and depth of their preparatory research?]] ME.1.3
- [[What systems-thinking approaches can optimize the interplay between breadth and focus in Preparation|What systems-thinking approaches can optimize the interplay between breadth and focus in Preparation?]] ME.1.4
- [[How does iterative engagement with preparatory materials generate emergent cognitive structures|How does iterative engagement with preparatory materials generate emergent cognitive structures?]] ME.1.5
- [[Why is managing paradoxes of certainty and uncertainty critical in the early framing of creative work|Why is managing paradoxes of certainty and uncertainty critical in the early framing of creative work?]] ME.1.6
- [[How can Preparation be reconceptualized as a dynamic threshold crossing in creative cognition|How can Preparation be reconceptualized as a dynamic threshold crossing in creative cognition?]] ME.1.7
- [[What role does the artist’s agency play in negotiating external and internal boundaries during Preparation|What role does the artist’s agency play in negotiating external and internal boundaries during Preparation?]] ME.1.8
- [[How can affective tones during Preparation influence the cultural resonance of creative output|How can affective tones during Preparation influence the cultural resonance of creative output?]] ME.1.9
- [[What implications does Preparation have for the continuity and disruption of creative trajectories|What implications does Preparation have for the continuity and disruption of creative trajectories?]] ME.1.10
- [[How can Preparation integrate multi-scalar perspectives to enrich conceptual framing|How can Preparation integrate multi-scalar perspectives to enrich conceptual framing?]] ME.1.11
- [[How might meta-reflective practices in Preparation inform an artist’s evolving authorial strategy|How might meta-reflective practices in Preparation inform an artist’s evolving authorial strategy?]] ME.1.12

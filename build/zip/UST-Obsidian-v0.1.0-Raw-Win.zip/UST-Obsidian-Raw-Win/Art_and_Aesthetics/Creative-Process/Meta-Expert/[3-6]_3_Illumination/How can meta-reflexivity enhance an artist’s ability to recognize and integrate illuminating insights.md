**Question ID:** Creative-Process.ME.3.3

**Concept:** [[Reflexivity]]

**Structure Part:** [[_Creative-Process-ME-[3-6]_3_Illumination]]

**Level:** Meta/Expert

**Structure:** [[_Creative-Process]]

**Discipline:** Art and Aesthetics


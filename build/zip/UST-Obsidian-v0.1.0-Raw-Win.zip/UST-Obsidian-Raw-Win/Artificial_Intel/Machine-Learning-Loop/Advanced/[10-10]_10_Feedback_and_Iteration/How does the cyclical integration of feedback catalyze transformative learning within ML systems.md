**Question ID:** Machine-Learning-Loop.A.10.1

**Concept:** [[Cycle]]

**Structure Part:** [[_Machine-Learning-Loop-A-[10-10]_10_Feedback_and_Iteration]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


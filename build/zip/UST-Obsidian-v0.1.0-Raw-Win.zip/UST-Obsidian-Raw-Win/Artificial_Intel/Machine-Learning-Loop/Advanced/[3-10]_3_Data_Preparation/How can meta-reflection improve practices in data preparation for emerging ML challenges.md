**Question ID:** Machine-Learning-Loop.A.3.12

**Concept:** [[Reflexivity]]

**Structure Part:** [[_Machine-Learning-Loop-A-[3-10]_3_Data_Preparation]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


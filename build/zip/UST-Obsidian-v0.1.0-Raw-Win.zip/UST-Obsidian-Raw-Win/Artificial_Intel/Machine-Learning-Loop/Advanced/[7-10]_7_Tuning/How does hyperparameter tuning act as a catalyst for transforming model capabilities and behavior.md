**Question ID:** Machine-Learning-Loop.A.7.1

**Concept:** [[Transformation]]

**Structure Part:** [[_Machine-Learning-Loop-A-[7-10]_7_Tuning]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


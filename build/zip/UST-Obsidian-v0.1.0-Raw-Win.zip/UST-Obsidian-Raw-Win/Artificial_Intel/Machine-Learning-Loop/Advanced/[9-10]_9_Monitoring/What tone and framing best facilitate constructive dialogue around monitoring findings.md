**Question ID:** Machine-Learning-Loop.A.9.11

**Concept:** [[Tone]]

**Structure Part:** [[_Machine-Learning-Loop-A-[9-10]_9_Monitoring]]

**Level:** Advanced

**Structure:** [[_Machine-Learning-Loop]]

**Discipline:** Artificial Intel.


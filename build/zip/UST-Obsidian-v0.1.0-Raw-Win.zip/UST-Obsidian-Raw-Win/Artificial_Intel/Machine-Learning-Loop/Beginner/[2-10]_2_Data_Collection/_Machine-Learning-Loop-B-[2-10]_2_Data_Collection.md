[[_Machine-Learning-Loop]]

2. Data Collection → Gathering raw data from various sources relevant to the defined problem

Questions for **[2/10] 2. Data Collection** at level **Beginner**:

- [[Where does the data come from and how is it gathered|Where does the data come from and how is it gathered?]] B.2.1
- [[What types of data are most relevant to the problem definition|What types of data are most relevant to the problem definition?]] B.2.2
- [[How do we know if we have enough data to work with|How do we know if we have enough data to work with?]] B.2.3
- [[What makes some data sources more reliable than others|What makes some data sources more reliable than others?]] B.2.4
- [[How does data bias enter the system during this phase|How does data bias enter the system during this phase?]] B.2.5
- [[Why is it important to document how and where the data was collected|Why is it important to document how and where the data was collected?]] B.2.6
- [[What could happen if critical populations or examples are underrepresented in the data|What could happen if critical populations or examples are underrepresented in the data?]] B.2.7
- [[What if real-time data collection contradicts previously gathered datasets|What if real-time data collection contradicts previously gathered datasets?]] B.2.8
- [[How does the source of data affect public perception of legitimacy or bias|How does the source of data affect public perception of legitimacy or bias?]] B.2.9
- [[What role does tone or framing in the data source (e.g., social media posts) play in training models|What role does tone or framing in the data source (e.g., social media posts) play in training models?]] B.2.10
- [[How might automated scraping or sensors alter what counts as 'real' data|How might automated scraping or sensors alter what counts as 'real' data?]] B.2.11
- [[What makes a dataset ethically and practically usable in ML systems|What makes a dataset ethically and practically usable in ML systems?]] B.2.12
